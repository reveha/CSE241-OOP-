/**
 *
 * @author abdullah reveha
 */
public interface Visual {
    public void display(); // Abstract method for Visual interface
}
