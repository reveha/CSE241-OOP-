/**
 *
 * @author abdullah reveha
 */
public interface NonVisual {
    public void show(); // Abstract method for interface
}
