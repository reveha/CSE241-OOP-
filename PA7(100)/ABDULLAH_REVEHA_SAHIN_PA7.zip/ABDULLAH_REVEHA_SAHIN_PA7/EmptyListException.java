/**
 *
 * @author abdullah reveha
 */

import java.util.*;

public class EmptyListException extends Exception{ // EmptyListException to catch empty ArrayList

    public EmptyListException(String string) {
        super(string);
    }
    
}
