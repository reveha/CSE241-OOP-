/**
 *
 * @author abdullah reveha
 */
public class InvalidIndexException extends Exception{

    public InvalidIndexException(String string) {
        super(string);
    }
    
}
